# -*- coding: utf-8 -*-
"""
Created on Tue Aug 24 13:35:53 2021

@author: kevin
"""
from math import exp
from math import sqrt
from math import pi


import matplotlib.pyplot as plt

day = 0
lday  = 200

dayinc = (lday-day)/1000

L = []
T = []


class CSM():
    def __init__(self):
        self.define_csm_vars()
            
    def define_csm_vars(self,):

        self.Bf =  1.226
        self.Br = .987
        self.A = .038
    
        self.K =.08
        self.Mo = 2e33
        self.M = 5*self.Mo #mej
        self.B=13.8
        self.c = 3e10
        
        self.Rocsm = 6.96e10



## 
        self.Vsc=1e9
        #self.Eni0 = 4.78e10

## 
        #self.Mni = .6*Mo
        self.Ro=9
        
        #self.To = (self.K*self.M)/(self.B*self.c*self.Ro)
        #self.Th = self.Ro/self.Vsc
        
        #self.tm = sqrt(2*self.To*self.Th)
        #tni =7.605e5
        
#        eco0 = 2.561e8
#        tco = 9.822e6
        
#        y = (tm/(2*tni))
        
        self.Mcsm = .1*self.Mo
        #change 100-3000 Ro
        self.rcsm = 1000*self.Rocsm
        self.rp = 1*self.Rocsm
        self.pcsm = (3*self.Mcsm)/(4*pi*self.rcsm**3)

        self.tocsm = (self.K*self.Mcsm/(self.B*self.c*self.rcsm))

        self.delta = 2
        self.n = 12
        self.s = 2

        self.esn = 1e51#(Vsc**2*(5/3)*M)/2



        self.gn = (((1/(4*pi*(self.n-self.delta))
                     )*(2*(5-self.delta)*(self.n-5)*self.esn)**(
                         (self.n-3)/2))/( 
            ((3-self.delta)*(self.n-3)*self.M)**((self.n-5)/2)))    
        self.q = self.pcsm*self.rp**self.s


# using vsc for vsn instead saving one variable.
        self.ti = self.rp/self.Vsc


## imaginary?
        self.tfstar = (((((3-self.s)*self.q**((3-self.n)/(self.n-self.s))
            )*(self.A*self.gn)**((self.s-3)/(self.n-self.s)))/ 
          (4*pi*self.Bf**(3-self.s))
          )**((self.n-self.s)/((self.n-3)*(3-self.s))
              ))*self.Mcsm**((self.n-self.s)/((self.n-3)*(3-self.s)))
                
        self.trstar = ((self.Vsc/(self.Br*(self.A*self.gn/self.q)**(1/(self.n-self.s))
                ))*((1-((3-self.n)*self.M)/
                (4*pi*(self.Vsc**(3-self.n))*self.gn))**(1/(3-self.n)
                                          )))**((self.n-self.s)/(self.s-3))

    
    def thetastep(x, y):
        if x > 0:
            return 1
        if x<=0:
            return 0
        #+\
    def funccsm(self, t):
        print(type(self.tfstar-t))
        
        return exp(t/self.tocsm) * (((2*pi) / ((self.n-self.s)**3)) * (self.gn**((5-self.s) 
                /(self.n - self.s))) * self.q**((self.n - 5)/(self.n - self.s)
                ) * ((self.n - 3)**2) * (self.n - 5) * (self.Bf**(5-self.s)) * (self.A**(
                (5 - self.s) / (self.n - self.s))) * (t + self.ti)**(
                (2 * self.n + 6 * self.s - self.n * self.s-15) / (self.n - self.s)
                ) * 
                self.thetastep(self.tfstar - t) +
                (2 * pi) * ((self.A * self.gn / self.q)**(
                (5-self.n) / (self.n - self.s))) * (self.Br**(5 - self.n)) * self.gn * (
                ((3 - self.s) / (self.n - self.s))**3)+\
                (t + self.ti)**((2*self.n + 6*self.s - self.n * self.s - 15)
                /(self.n - self.s)) * self.thetastep((self.trstar - t)))
                
                
    def simp(self, t):
                
                
        x0=0
        
        n = 600
        xi = (t-x0)/n   
        tot = 0
        st = self.funccsm(x0)
        end = self.funccsm(t)
        
        
        con = 3*xi/8
        for i in range (1,n):
            x=x0+xi*i
            if i%3 ==0:
                sim =2*self.funccsm(x)
            else:
                sim = 3*self.funccsm(x)
            tot += sim 
        return(con*(tot+st+end))
        
        
    def Lambdacsm(self, t):
        return (1/self.tocsm)*exp(-t/self.tocsm)*self.simp(t)

    def Lum(self, day):
        t = 86400*day
       # xsec = t/tm
        #D(xsec,y,1)*
        #return (D(xsec,y,1)*Eni0*exp(-t/tni)+
        #        D(xsec,y,355)*(eco0*exp(-t/tco)))*Mni*Lambda(xsec, y)
        return  self.Lambdacsm(t) #+ Lambda(xsec, y)* Mni*Eni0
        #return (Eni0*exp(-t/tni)+
        #       (eco0*exp(-t/tco)))*Mni*Lambda(xsec, y)            
    
        #return (Eni0*exp(-t/tni))*Mni*Lambda(xsec, y)
'''
#arnett
def D(x,y,s):
    tau = s*(55.3*(.1/K)*y**2)/((Vsc/1e9)*(.1+2*x*y)**2)
    g = tau/(tau+1.6)
    return g*(1+2*g*(1-g)*(1-.75*g))

def func(z, y):
    return (D(z,y,1)*exp(-2*z*y+z**2) + 5.36e-3*D(z,y,355)*exp(-2*.1548*z*y+z*z))*2*z

def simpstar(x1, y):
    
    
    x0=0
    
    n = 100
    xi = (x1-x0)/n   
    tot = 0
    st = func(x0,y)
    end = func(x1,y)
    
    
    con = 3*xi/8
    for i in range (1,n):
        x=x0+xi*i
        if i%3 ==0:
            sim =2*func(x, y)
        else:
            sim = 3*func(x,y)
        tot += sim 
    return(con*(tot+st+end))

def Lambda(x,y):
    return exp(-x**2)*simpstar(x,y)
'''
csmstar = CSM()
for i in range (0 , 1000):
    L.append(csmstar.Lum(day))
    T.append(day)
    
    day += dayinc
    
fig, ax = plt.subplots(ncols=1,nrows=1)
#ax.plot(data_x, data_y, "o")
    
ax.plot(T, L)


ax.set_yscale("log")

#ax.set_xscale('log')

ax.set_xlabel("time (day)")
ax.set_ylabel("luminosity (erg/s)")

            